import socket
import sqlite3
import datetime
from sklearn.ensemble import IsolationForest
import numpy as np

# ================================
# 📡 إعدادات السيرفر
# ================================
HOST_IP = '0.0.0.0'  # 0.0.0.0 تعني استقبال الاتصال من أي جهاز على الشبكة
PORT = 8080          # يجب أن يطابق المنفذ في كود ESP32
DB_NAME = "sensors_v2.db"

# ================================
# 🧠 تهيئة وتدريب الذكاء الاصطناعي
# ================================
# نقوم بتدريب النموذج على قيم "طبيعية" متوقعة حتى لا يعطي إنذارات كاذبة
# الترتيب: [Temp (C), Vib (V), Amp (A), Volt (V)]
training_data = [
    [25.0, 9.8, 1.5, 220.0],  # حالة مثالية
    [30.0, 9.85, 3.0, 218.0],  # حمل متوسط
    [35.0, 10.5, 4.5, 215.0],  # حمل خفيف
    [40.0, 11.0, 4.8, 225.0],  # حمل عالي قليلاً
    [28.0, 9.7, 0.0, 220.0]   # الجهاز متوقف (تيار صفر)
]

print(" The artificial intelligence model is currently being trained...")
clf = IsolationForest(contamination=0.05, random_state=42)
clf.fit(np.array(training_data))
print(" The training was successful!")

# ================================
# 💾 دالة تخزين البيانات وتحليلها
# ================================
def save_to_db(data):
    try:
        # الاتصال بقاعدة البيانات
        conn = sqlite3.connect(DB_NAME)
        # تفعيل وضع WAL لتسريع الكتابة ومنع الأخطاء
        conn.execute("PRAGMA journal_mode=WAL;") 
        c = conn.cursor()
        
        # إنشاء الجدول إذا لم يكن موجوداً
        c.execute('''CREATE TABLE IF NOT EXISTS sensor_data_full 
                     (timestamp TEXT, temp_c REAL, accel_val REAL, current_a REAL, voltage_v REAL, 
                     is_anomaly INTEGER, anomaly_score REAL)''')
        
        # تحليل البيانات باستخدام الـ AI
        f = np.array([data])
        is_bad = clf.predict(f)[0]   # الناتج: 1 (طبيعي) أو -1 (خطر)
        
        # حساب نسبة الشذوذ (للعرض فقط)
        score = -clf.score_samples(f)[0]
        score = (score + 0.5) if score < 0.5 else score
        score = max(0, min(1, score))

        # حفظ البيانات
        ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        c.execute("INSERT INTO sensor_data_full VALUES (?,?,?,?,?,?,?)", 
                  (ts, data[0], data[1], data[2], data[3], int(is_bad), score))
        
        conn.commit()
        conn.close()
        return is_bad
    except Exception as e:
        print(f"\n❌ Database Error: {e}")
        return 1

# ================================
# 🚀 تشغيل السيرفر الرئيسي
# ================================
print(f"\n📡 The server is running and waiting for ESP32 on port {PORT}...")
print(f"⚠️ Note: Make sure the computer's IP address is correct in the Arduino code.")
print("-" * 60)
print(f"{'Time':<12} | {'Status':<8} | {'Temp':<8} | {'Vib':<8} | {'Amp':<8} | {'Volt':<8}")
print("-" * 60)

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST_IP, PORT))
server_socket.listen(5)

try:
    while True:
        client_socket, addr = server_socket.accept()
        # استقبال البيانات (نتوقع استقبال بايتات قليلة)
        data_bytes = client_socket.recv(1024)
        
        if data_bytes:
            try:
                line = data_bytes.decode('utf-8').strip()
                parts = line.split(',')
                
                # التأكد أن البيانات كاملة (4 قيم)
                if len(parts) == 4:
                    vals = [float(p) for p in parts]
                    
                    # حفظ وتحليل
                    is_bad = save_to_db(vals)
                    
                    # تنسيق العرض
                    status_icon = "🟢 OK " if is_bad == 1 else "🔴 BAD"
                    timestamp = datetime.datetime.now().strftime('%H:%M:%S')
                    
                    # طباعة السطر (تحديث في نفس المكان أو سطر جديد حسب الرغبة)
                    # \r تجعل الكتابة تعود لبداية السطر (Update mode)
                    # إزالة \r تجعلها تطبع سطراً جديداً لكل قراءة (Log mode)
                    print(f"\r{timestamp} | {status_icon} | {vals[0]:5.1f}°C | {vals[1]:4.2f}V  | {vals[2]:4.2f}A  | {vals[3]:5.1f}V ", end="", flush=True)
                    
            except ValueError:
                pass # تجاهل الأخطاء في التحويل
            except Exception as e:
                print(f"\nError: {e}")
                
        client_socket.close()

except KeyboardInterrupt:
    print("\n\n🛑 The server has been manually shut down.")
    server_socket.close()
