import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text
import time
import plotly.graph_objects as go
from datetime import datetime
import numpy as np
import requests 
from io import BytesIO 
from sklearn.ensemble import IsolationForest

# --- 1. إعدادات الصفحة ---
st.set_page_config(
    page_title="4SEE",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ==========================================
# 🛑 إعدادات تيليجرام 🛑
# ==========================================
TELEGRAM_TOKEN = '8515131714:AAGPXchXKA5zQflhN4cHVLZKDqZGPZLb6wo'
TELEGRAM_CHAT_ID = '-1003395953179' 

def send_telegram_alert(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}
        requests.post(url, json=payload, timeout=3)
    except: pass

def send_telegram_files(df_to_send):
    timestamp = datetime.now().strftime('%H-%M-%S')
    # إرسال ملف CSV واحد
    try:
        csv_buffer = BytesIO()
        df_to_send.to_csv(csv_buffer, encoding='utf-8-sig')
        csv_buffer.seek(0)
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendDocument"
        files = {'document': (f"Log_{timestamp}.csv", csv_buffer, 'text/csv')}
        data = {'chat_id': TELEGRAM_CHAT_ID, 'caption': '📄 نسخة CSV'}
        requests.post(url, data=data, files=files, timeout=10)
    except: pass

    # إرسال ملف Excel واحد
    try:
        xlsx_buffer = BytesIO()
        with pd.ExcelWriter(xlsx_buffer, engine='openpyxl') as writer:
            df_to_send.to_excel(writer, sheet_name='Sensor Data')
        xlsx_buffer.seek(0)
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendDocument"
        files = {'document': (f"Log_{timestamp}.xlsx", xlsx_buffer, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
        data = {'chat_id': TELEGRAM_CHAT_ID, 'caption': '📊 نسخة Excel'}
        requests.post(url, data=data, files=files, timeout=10)
    except: pass

# ==========================================

# --- 2. الترجمة ---
TRANS = {
    'AR': {
        'title': "4SEE",
        'subtitle': "نظام مراقبة الأداء الصناعي ",
        'settings': "الإعدادات",
        'speed': "سرعة التحديث (ث)",
        'history': "طول السجل",
        'clear': "مسح البيانات",
        'wait': "جاري انتظار البيانات...",
        'tabs': ["لوحة العدادات", "التحليل المتقدم", "سجل البيانات", "العمر الافتراضي"],
        'safe': "النظام مستقر - جميع القراءات ضمن النطاق الآمن",
        'danger': "تحذير: تم اكتشاف قراءات شاذة!",
        'temp': "درجة الحرارة",
        'vib': "مستوى الاهتزاز",
        'curr': "شدة التيار",
        'volt': "الجهد الكهربائي",
        'risk': "مؤشر الخطر",
        'bot_head': "🚨 <b>إنذار عطل!</b>",
        'bot_caption': "القراءات الشاذة فقط:",
        'chart_title': "تحليل الأداء الزمني للمعايير الحرجة",
        'dl_csv': "تحميل CSV",
        'dl_excel': "تحميل Excel",
        'stats_title': "إحصائيات سريعة",
        'last_update': "آخر تحديث",
        'total_readings': "إجمالي القراءات",
        'anomalies': "القراءات الشاذة",
        'pred_title': "العمر الافتراضي والذكاء الاصطناعي",
        'rul': "العمر المتبقي المتوقع (RUL)",
        'status': "الحالة المتوقعة"
    },
    'EN': {
        'title': "4SEE",
        'subtitle': "Industrial Performance Monitoring System",
        'settings': "Settings",
        'speed': "Refresh Rate (s)",
        'history': "History Length",
        'clear': "Clear Data",
        'wait': "Waiting for data...",
        'tabs': ["Dashboard", "Advanced Analysis", "Data Log", "Expected lifespan"],
        'safe': "System Nominal - All Readings Within Safe Range",
        'danger': "Warning: Anomalies Detected!",
        'temp': "Temperature",
        'vib': "Vibration Level",
        'curr': "Current",
        'volt': "Voltage",
        'risk': "Risk Score",
        'bot_head': "🚨 <b>Anomaly Alert!</b>",
        'bot_caption': "Abnormal Readings Only:",
        'chart_title': "Temporal Performance Analysis of Critical Parameters",
        'dl_csv': "Download CSV",
        'dl_excel': "Download Excel",
        'stats_title': "Quick Statistics",
        'last_update': "Last Update",
        'total_readings': "Total Readings",
        'anomalies': "Anomalies Detected",
        'pred_title': "Expected lifespan & AI",
        'rul': "Remaining Useful Life (RUL)",
        'status': "Predicted Status"
    }
}

# --- 3. قاعدة البيانات ---
@st.cache_resource
def get_engine():
    try:
        DATABASE_URL = "sqlite:///./sensors_v2.db"
        engine = create_engine(DATABASE_URL)
        return engine
    except: return None

engine = get_engine()

# --- 4. CSS (التبويبات) ---
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');

    /* 1. خلفية التطبيق */
    .main {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
    }
    .main .block-container { padding-top: 1rem; padding-bottom: 2rem; }
    
    /* 2. القائمة الجانبية */
    section[data-testid="stSidebar"] {
        background-color: #0f2027;
        background-image: linear-gradient(315deg, #0f2027 0%, #203a43 74%);
    }
    section[data-testid="stSidebar"] * { color: #ffffff !important; }
    
    /* 3. العنوان الرئيسي */
    .custom-title {
        background: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
        color: white;
        padding: 40px 20px;
        border-radius: 20px;
        text-align: center;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
        margin-bottom: 30px;
        border: 1px solid rgba(255,255,255,0.1);
    }
    .custom-title h1 {
        margin: 0;
        font-family: 'Pacifico', cursive !important;
        font-size: 6em !important;
        font-weight: 400;
        line-height: 1.2;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
    }
    .custom-title p {
        margin: 10px 0 0 0;
        font-size: 1.2em;
        opacity: 0.9;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    /* 4. تنسيق التبويبات (Tabs Styling) */
    
    /* إزالة الخلفية والحواف من حاوية التبويبات الرئيسية */
    .stTabs [data-baseweb="tab-list"] {
        gap: 10px;
        background-color: transparent;
        padding: 10px;
        border: none !important;
        box-shadow: none !important;
    }

    /* تنسيق الزر الواحد في التبويب */
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 8px;
        color: #1e3c72;
        font-weight: 600;
        /* إزالة الحواف والظلال في الوضع العادي */
        border: none !important;
        box-shadow: none !important;
        transition: all 0.2s;
    }

    /* عند تمرير الماوس (Hover) - يظهر الإطار الأزرق */
    .stTabs [data-baseweb="tab"]:hover {
        border: 2px solid #1e3c72 !important; /* يظهر الإطار فقط هنا */
        color: #1e3c72;
        background-color: white;
    }

    /* التبويب المختار (Selected) - خلفية زرقاء */
    .stTabs [aria-selected="true"] {
        background-color: #1e3c72 !important;
        color: white !important;
        border: none !important;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3) !important;
    }

    /* 5. البطاقات والرسوم */
    .metric-card {
        background: linear-gradient(135deg, #1c2e4a 0%, #283e51 100%);
        border: none; border-radius: 16px; padding: 20px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.2);
        color: white; text-align: center;
    }
    div[data-testid="stPlotlyChart"] {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 12px; padding: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.2);
    }
    .stats-box {
        background: white; border-radius: 12px; padding: 20px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        text-align: center; margin-bottom: 20px;
    }
    .stats-box h3 { color: #1e3c72; margin: 0; font-size: 2em; font-weight: 700; }
    .stats-box p { color: #555; margin: 5px 0 0 0; font-size: 0.9em; }
    .stDataFrame { border-radius: 12px; overflow: hidden; background-color: white; }
    
    iframe[title="streamlit.components.v1.html"] { display: none; }
    .pred-box { background: #f8fafc; border-left: 5px solid #1e3c72; padding: 15px; border-radius: 8px; margin-top: 10px; }
</style>
""", unsafe_allow_html=True)

# --- 5. الدوال المساعدة ---
def create_gauge(value, title, min_val, max_val, safe_limit, danger_limit, unit=""):
    if value <= safe_limit: bar_color = "#10b981"
    elif value <= danger_limit: bar_color = "#f59e0b"
    else: bar_color = "#ef4444"
    
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta", value = value,
        title = {'text': f"<b>{title}</b>", 'font': {'size': 22, 'color': "#1f2937"}},
        number = {'suffix': unit, 'font': {'size': 28, 'color': "#111827", 'family': "Arial Black"}},
        delta = {'reference': safe_limit, 'increasing': {'color': "#ef4444"}, 'decreasing': {'color': "#10b981"}},
        gauge = {
            'axis': {'range': [min_val, max_val], 'tickwidth': 2, 'tickcolor': "#6b7280"},
            'bar': {'color': bar_color, 'thickness': 0.75},
            'bgcolor': "white", 'borderwidth': 2, 'bordercolor': "#e5e7eb",
            'steps': [{'range': [min_val, safe_limit], 'color': '#d1fae5'}, {'range': [safe_limit, danger_limit], 'color': '#fef3c7'}, {'range': [danger_limit, max_val], 'color': '#fee2e2'}],
            'threshold': {'line': {'color': "#dc2626", 'width': 4}, 'thickness': 0.75, 'value': danger_limit}
        }
    ))
    fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=280, margin=dict(l=20, r=20, t=70, b=20), font={'family': 'Arial, sans-serif'})
    return fig

def create_voltage_gauge(value, title, min_val, max_val, low_limit, high_limit):
    if low_limit <= value <= high_limit: bar_color = "#10b981"
    else: bar_color = "#ef4444"
    
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta", value = value,
        title = {'text': f"<b>{title}</b>", 'font': {'size': 22, 'color': "#1f2937"}},
        number = {'suffix': "V", 'font': {'size': 28, 'color': "#111827"}},
        delta = {'reference': 220, 'increasing': {'color': "#3b82f6"}, 'decreasing': {'color': "#3b82f6"}},
        gauge = {
            'axis': {'range': [min_val, max_val], 'tickwidth': 2, 'tickcolor': "#6b7280"},
            'bar': {'color': bar_color, 'thickness': 0.75},
            'bgcolor': "white", 'borderwidth': 2, 'bordercolor': "#e5e7eb",
            'steps': [{'range': [min_val, low_limit], 'color': '#fee2e2'}, {'range': [low_limit, high_limit], 'color': '#d1fae5'}, {'range': [high_limit, max_val], 'color': '#fee2e2'}],
            'threshold': {'line': {'color': "#dc2626", 'width': 4}, 'thickness': 0.75, 'value': value}
        }
    ))
    fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=280, margin=dict(l=20, r=20, t=70, b=20), font={'family': 'Arial, sans-serif'})
    return fig

def generate_sample_data(limit):
    dates = pd.date_range(end=datetime.now(), periods=limit, freq='1s')
    data = {'temp_c': np.random.normal(70, 5, limit), 'accel_val': np.random.normal(0.2, 0.05, limit), 'current_a': np.random.normal(5.0, 1.0, limit), 'voltage_v': np.random.normal(12.0, 0.5, limit), 'anomaly_score': np.zeros(limit), 'is_anomaly': np.ones(limit)}
    return pd.DataFrame(data, index=dates)

def load_data(limit=200):
    try:
        if engine is None: return generate_sample_data(limit)
        with engine.connect() as conn:
            conn.execute(text('''CREATE TABLE IF NOT EXISTS sensor_data_full (timestamp TEXT, temp_c REAL, accel_val REAL, current_a REAL, voltage_v REAL, is_anomaly INTEGER, anomaly_score REAL)'''))
        query = f"SELECT * FROM sensor_data_full ORDER BY timestamp DESC LIMIT {limit}"
        df = pd.read_sql(query, engine)
        if df.empty: return generate_sample_data(limit)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.set_index('timestamp').sort_index()
        if len(df) < 50:
            df['is_anomaly'] = df.apply(lambda r: -1 if (r['temp_c']>85 or r['current_a']>10) else 1, axis=1)
            df['anomaly_score'] = 0.1
            return df
        X = df[['temp_c', 'accel_val', 'current_a', 'voltage_v']]
        model = IsolationForest(contamination=0.05, random_state=42, n_estimators=50)
        df['is_anomaly'] = model.fit_predict(X)
        scores = -model.score_samples(X)
        min_s, max_s = scores.min(), scores.max()
        df['anomaly_score'] = (scores - min_s) / (max_s - min_s) if (max_s - min_s) > 0 else 0.0
        return df
    except: return generate_sample_data(limit)

def get_stats(df):
    if df.empty: return {}
    last = df.iloc[-1]
    return {'temp': last['temp_c'], 'vib': last['accel_val'], 'amp': last['current_a'], 'volt': last['voltage_v'], 'is_alarm': last['is_anomaly'] == -1, 'score': last['anomaly_score']}

def calculate_trend_and_prediction(df, column_name, threshold, future_steps=30):
    if len(df) < 10: return None, None, "Analyzing...", "#6b7280"
    recent_df = df.tail(50).copy()
    y = recent_df[column_name].values
    x = np.arange(len(y))
    slope, intercept = np.polyfit(x, y, 1)
    future_x = np.arange(len(y), len(y) + future_steps)
    future_y = slope * future_x + intercept
    ttf_text, status_color = "STABLE", "#10b981"
    if slope > 0.01:
        steps_to_threshold = (threshold - intercept) / slope
        remaining_steps = steps_to_threshold - len(y)
        if remaining_steps <= 0: ttf_text, status_color = "CRITICAL (Limit Reached)", "#ef4444"
        elif remaining_steps < future_steps * 2: ttf_text, status_color = f"Warning: Limit in ~{max(0, int(remaining_steps))}s", "#f59e0b"
        else: ttf_text, status_color = "Trend Increasing (Safe)", "#3b82f6"
    elif slope < -0.01: ttf_text, status_color = "Cooling Down / Decreasing", "#10b981"
    return future_x, future_y, ttf_text, status_color

# --- 6. الواجهة ---
with st.sidebar:
    st.markdown("### Language / اللغة")
    lang_choice = st.radio("", ['AR', 'EN'], horizontal=True, label_visibility="collapsed")
    T = TRANS[lang_choice]
    st.markdown("---")
    st.markdown(f"### {T['settings']}")
    auto_update = st.checkbox("تحديث تلقائي / Auto Update", value=True)
    ref_rate = st.slider(T['speed'], 0.5, 5.0, 1.0, 0.5)
    history_len = st.slider(T['history'], 50, 500, 200, 50)
    st.markdown("---")
    if st.button(T['clear'], use_container_width=True):
        with engine.connect() as conn: 
            conn.execute(text("DELETE FROM sensor_data_full"))
            conn.commit()
        st.rerun()

st.markdown(f"""<div class="custom-title"><h1>{T['title']}</h1><p>{T['subtitle']}</p></div>""", unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs(T['tabs'])
with tab1: dashboard_container = st.empty()
with tab2: chart_container = st.empty()
with tab3: table_container = st.empty()
with tab4: prediction_container = st.empty()

# --- 7. منطق التنبيه (Single Shot Logic) ---
# المتغير في الذاكرة يحفظ توقيت آخر رسالة
if 'last_telegram_sent_time' not in st.session_state:
    st.session_state['last_telegram_sent_time'] = 0

# فترة الانتظار الإجبارية (بالثواني) - 10 ثواني
COOLDOWN_SECONDS = 10

while True:
    if not auto_update:
        time.sleep(1)
        continue

    df = load_data(history_len)
    stats = get_stats(df)
    u_key = int(time.time()*1000)

    if df.empty:
        dashboard_container.warning(T['wait'])
        time.sleep(1)
        continue

    # ===============================================
    # 🛑 منطق إرسال رسالة واحدة وإهمال الباقي 🛑
    # ===============================================
    current_time = time.time()
    
    # 1. هل يوجد عطل الآن؟
    is_anomaly = stats.get('is_alarm', False)
    
    # 2. هل انتهت فترة الانتظار (5 دقائق)؟
    time_passed = current_time - st.session_state['last_telegram_sent_time']
    is_cooldown_over = time_passed > COOLDOWN_SECONDS

    # الشرط الصارم: نرسل فقط إذا كان هناك عطل + انتهى وقت الانتظار
    if is_anomaly and is_cooldown_over:
        # تحديث وقت آخر إرسال فوراً لمنع أي رسالة أخرى
        st.session_state['last_telegram_sent_time'] = current_time
        
        # تجهيز الرسالة الواحدة
        bad_readings = []
        if stats['temp'] > 85: bad_readings.append(f"🌡️ {T['temp']}: {stats['temp']:.1f}°C")
        if stats['amp'] > 10:  bad_readings.append(f"⚡ {T['curr']}: {stats['amp']:.2f}A")
        if stats['volt'] < 11 or stats['volt'] > 13: bad_readings.append(f"🔌 {T['volt']}: {stats['volt']:.1f}V")
        if stats['vib'] > 11.0: bad_readings.append(f"〰️ {T['vib']}: {stats['vib']:.2f} m/s²")
        if not bad_readings: bad_readings.append(f"🤖 AI Anomaly (Score: {stats['score']:.2f})")
        
        msg = f"{T['bot_head']}\n\n{T['bot_caption']}\n" + "\n".join(bad_readings) + f"\n\n⏱️ {datetime.now().strftime('%H:%M:%S')}"
        
        # إرسال الرسالة والملفات مرة واحدة فقط
        send_telegram_alert(msg)
        send_telegram_files(df.tail(20))
        st.toast("Alert Sent! cooling for 10s.", icon="📨")
    # ===============================================

    with dashboard_container.container():
        if stats.get('is_alarm'): st.error(f"### {T['danger']}\n**{T['risk']}: {stats['score']:.2f}**")
        else: st.success(f"### {T['safe']}")
        st.markdown("---")
        
        col_s1, col_s2, col_s3, col_s4 = st.columns(4)
        with col_s1: st.markdown(f"""<div class="stats-box"><h3>{len(df)}</h3><p>{T['total_readings']}</p></div>""", unsafe_allow_html=True)
        with col_s2: 
            ac = len(df[df['is_anomaly'] == -1])
            st.markdown(f"""<div class="stats-box"><h3 style="color: {'#ef4444' if ac > 0 else '#10b981'}">{ac}</h3><p>{T['anomalies']}</p></div>""", unsafe_allow_html=True)
        with col_s3: st.markdown(f"""<div class="stats-box"><h3>{stats['score']:.2f}</h3><p>{T['risk']}</p></div>""", unsafe_allow_html=True)
        with col_s4: st.markdown(f"""<div class="stats-box"><h3>{datetime.now().strftime('%H:%M:%S')}</h3><p>{T['last_update']}</p></div>""", unsafe_allow_html=True)
        st.markdown("---")
        
        c1, c2 = st.columns(2)
        c1.plotly_chart(create_gauge(stats['temp'], T['temp'], 0, 120, 75, 85, "°C"), use_container_width=True, key=f"g1_{u_key}")
        c2.plotly_chart(create_gauge(stats['vib'], T['vib'], 0, 20.0, 10.5, 12.0, " m/s²"), use_container_width=True, key=f"g2_{u_key}")
        c3, c4 = st.columns(2)
        c3.plotly_chart(create_gauge(stats['amp'], T['curr'], 0, 10, 4.5, 5.0, "A"), use_container_width=True, key=f"g3_{u_key}")
        c4.plotly_chart(create_voltage_gauge(stats['volt'], T['volt'], 0, 300, 160, 250), use_container_width=True, key=f"g4_{u_key}")

    with chart_container.container():
        st.markdown(f"### {T['chart_title']}")
        cc1, cc2 = st.columns(2)
        with cc1:
            fig1 = go.Figure()
            fig1.add_trace(go.Scatter(x=df.index, y=df['temp_c'], name=T['temp'], line=dict(color='#ef4444', width=3), yaxis='y'))
            fig1.add_trace(go.Scatter(x=df.index, y=df['current_a'], name=T['curr'], line=dict(color='#3b82f6', width=3), yaxis='y2'))
            fig1.update_layout(height=350, margin=dict(l=40, r=40, t=20, b=40), hovermode='x unified', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='white', xaxis=dict(showgrid=True, gridcolor='#e5e7eb'), yaxis=dict(title=dict(text=f"{T['temp']} (°C)", font=dict(color='#ef4444')), tickfont=dict(color='#ef4444'), showgrid=True, gridcolor='#e5e7eb'), yaxis2=dict(title=dict(text=f"{T['curr']} (A)", font=dict(color='#3b82f6')), tickfont=dict(color='#3b82f6'), overlaying='y', side='right'), legend=dict(orientation="h", y=1.02, x=0.5))
            st.plotly_chart(fig1, use_container_width=True, key=f"ch1_{u_key}")
        with cc2:
            fig2 = go.Figure()
            fig2.add_trace(go.Scatter(x=df.index, y=df['voltage_v'], name=T['volt'], line=dict(color='#10b981', width=3), yaxis='y'))
            fig2.add_trace(go.Scatter(x=df.index, y=df['accel_val'], name=T['vib'], line=dict(color='#8b5cf6', width=3), yaxis='y2'))
            fig2.update_layout(height=350, margin=dict(l=40, r=40, t=20, b=40), hovermode='x unified', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='white', xaxis=dict(showgrid=True, gridcolor='#e5e7eb'), yaxis=dict(title=dict(text=f"{T['volt']} (V)", font=dict(color='#10b981')), tickfont=dict(color='#10b981'), showgrid=True, gridcolor='#e5e7eb'), yaxis2=dict(title=dict(text=f"{T['vib']} (G)", font=dict(color='#8b5cf6')), tickfont=dict(color='#8b5cf6'), overlaying='y', side='right'), legend=dict(orientation="h", y=1.02, x=0.5))
            st.plotly_chart(fig2, use_container_width=True, key=f"ch2_{u_key}")
        st.markdown("---")
        st.markdown("#### Complete Overview")
        fig3 = go.Figure()
        fig3.add_trace(go.Scatter(x=df.index, y=df['temp_c'], name=T['temp'], line=dict(color='#ef4444', width=2), yaxis='y'))
        fig3.add_trace(go.Scatter(x=df.index, y=df['current_a'], name=T['curr'], line=dict(color='#3b82f6', width=2), yaxis='y'))
        fig3.add_trace(go.Scatter(x=df.index, y=df['voltage_v'], name=T['volt'], line=dict(color='#10b981', width=2, dash='dot'), yaxis='y2'))
        fig3.update_layout(height=400, hovermode='x unified', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='white', title="Temp & Current (Left) vs Voltage (Right)", xaxis=dict(showgrid=True, gridcolor='#eee'), yaxis=dict(title=dict(text="Temp (°C) / Current (A)"), showgrid=True, gridcolor='#eee'), yaxis2=dict(title=dict(text="Voltage (V)", font=dict(color='#10b981')), tickfont=dict(color='#10b981'), overlaying='y', side='right', showgrid=False), legend=dict(orientation="h", y=1.1))
        st.plotly_chart(fig3, use_container_width=True, key=f"ch3_{u_key}")
        st.markdown("---")
        st.markdown("#### Risk Score Distribution")
        fig_hist = go.Figure()
        fig_hist.add_trace(go.Histogram(x=df['anomaly_score'], nbinsx=30, name='Risk Score', marker=dict(color=df['anomaly_score'], colorscale='RdYlGn_r', showscale=True, colorbar=dict(title='Risk Level'))))
        fig_hist.update_layout(height=300, margin=dict(l=40, r=40, t=20, b=40), plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='white', xaxis=dict(showgrid=True, gridcolor='#e5e7eb', title=dict(text='درجة المخاطر / Risk Score')), yaxis=dict(showgrid=True, gridcolor='#e5e7eb', title=dict(text='التكرار / Frequency')), showlegend=False)
        st.plotly_chart(fig_hist, use_container_width=True, key=f"hist_{u_key}")

    with table_container.container():
        st.markdown("### Recent Readings Log")
        df_display = df.sort_index(ascending=False).head(50).copy()
        def highlight_anomalies(row): return ['background-color: #fee2e2; color: #991b1b'] * len(row) if row['is_anomaly'] == -1 else ['background-color: #d1fae5; color: #065f46'] * len(row)
        styled_df = df_display.style.apply(highlight_anomalies, axis=1).format({'temp_c': '{:.2f}°C', 'accel_val': '{:.3f}G', 'current_a': '{:.2f}A', 'voltage_v': '{:.2f}V', 'anomaly_score': '{:.3f}'})
        st.dataframe(styled_df, use_container_width=True, height=400)
        ci1, ci2, ci3, ci4 = st.columns(4)
        with ci1: st.metric(label="متوسط الحرارة", value=f"{df['temp_c'].mean():.1f}°C", delta=f"{stats['temp'] - df['temp_c'].mean():.1f}°C")
        with ci2: st.metric(label="متوسط الاهتزاز", value=f"{df['accel_val'].mean():.3f}G", delta=f"{stats['vib'] - df['accel_val'].mean():.3f}G")
        with ci3: st.metric(label="متوسط التيار", value=f"{df['current_a'].mean():.2f}A", delta=f"{stats['amp'] - df['current_a'].mean():.2f}A")
        with ci4: st.metric(label="متوسط الجهد", value=f"{df['voltage_v'].mean():.2f}V", delta=f"{stats['volt'] - df['voltage_v'].mean():.2f}V")
        st.markdown("---")
        st.markdown("### Detailed Vibration Analysis")
        fig_vib = go.Figure()
        fig_vib.add_trace(go.Scatter(x=df.index, y=df['accel_val'], name=T['vib'], line=dict(color='#8b5cf6', width=2), fill='tozeroy', fillcolor='rgba(139, 92, 246, 0.1)'))
        fig_vib.add_hline(y=0.5, line_dash="dash", line_color="#10b981", annotation_text="Safe Limit")
        fig_vib.add_hline(y=0.8, line_dash="dash", line_color="#ef4444", annotation_text="Danger Limit")
        fig_vib.update_layout(height=300, margin=dict(l=40, r=40, t=20, b=40), plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='white', showlegend=False, xaxis=dict(showgrid=True, gridcolor='#e5e7eb'), yaxis=dict(showgrid=True, gridcolor='#e5e7eb', title='G'))
        st.plotly_chart(fig_vib, use_container_width=True, key=f"vib_{u_key}")
        st.markdown("---")
        cd1, cd2 = st.columns(2)
        with cd1: st.download_button(label=f"{T['dl_csv']} 📄", data=df.to_csv(encoding='utf-8-sig'), file_name=f"data.csv", mime="text/csv", key=f"csv_{u_key}", use_container_width=True)
        with cd2: 
            buf = BytesIO()
            with pd.ExcelWriter(buf, engine='openpyxl') as w: df.to_excel(w)
            st.download_button(label=f"{T['dl_excel']} 📊", data=buf, file_name=f"data.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key=f"xlsx_{u_key}", use_container_width=True)
        
    with prediction_container.container():
        st.markdown(f"### {T['pred_title']}")
        pc1, pc2 = st.columns(2)
        with pc1:
            st.markdown(f"#### {T['temp']} ")
            fx, fy, tm, tc = calculate_trend_and_prediction(df, 'temp_c', 85)
            if fx is not None:
                fp1 = go.Figure()
                fp1.add_trace(go.Scatter(x=np.arange(len(df.tail(50))), y=df.tail(50)['temp_c'], mode='lines', name='History', line=dict(color='#ef4444', width=2)))
                fp1.add_trace(go.Scatter(x=fx, y=fy, mode='lines', name='Forecast', line=dict(color='#f59e0b', width=2, dash='dot')))
                fp1.add_hline(y=85, line_dash="dash", line_color="#333", annotation_text="Limit")
                fp1.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=20), paper_bgcolor='white', plot_bgcolor='rgba(0,0,0,0)', showlegend=True, legend=dict(orientation="h", y=1.1))
                st.plotly_chart(fp1, use_container_width=True, key=f"p1_{u_key}")
                st.markdown(f"""<div class="pred-box" style="border-left-color: {tc}"><h4 style="margin:0; color:{tc}">{T['status']}: {tm}</h4></div>""", unsafe_allow_html=True)
        with pc2:
            st.markdown(f"#### {T['vib']} ")
            fxv, fyv, tmv, tcv = calculate_trend_and_prediction(df,'accel_val',12.0) 
            if fxv is not None:
                fp2 = go.Figure()
                fp2.add_trace(go.Scatter(x=np.arange(len(df.tail(50))), y=df.tail(50)['accel_val'], mode='lines', name='History', line=dict(color='#8b5cf6', width=2)))
                fp2.add_trace(go.Scatter(x=fxv, y=fyv, mode='lines', name='Forecast', line=dict(color='#ec4899', width=2, dash='dot')))
                fp2.add_hline(y=12.0, line_dash="dash", line_color="#333", annotation_text="Limit")
                fp2.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=20), paper_bgcolor='white', plot_bgcolor='rgba(0,0,0,0)', showlegend=True, legend=dict(orientation="h", y=1.1))
                st.plotly_chart(fp2, use_container_width=True, key=f"p2_{u_key}")
                st.markdown(f"""<div class="pred-box" style="border-left-color: {tcv}"><h4 style="margin:0; color:{tcv}">{T['status']}: {tmv}</h4></div>""", unsafe_allow_html=True)
        st.markdown("---")
        
       
        st.markdown("---") 
        pc3, pc4 = st.columns(2)
        
        # 1. توقعات التيار
        with pc3:
            st.markdown(f"#### {T['curr']}")

            fxc, fyc, tmc, tcc = calculate_trend_and_prediction(df, 'current_a', 10.0)
            if fxc is not None:
                fp3 = go.Figure()
                fp3.add_trace(go.Scatter(x=np.arange(len(df.tail(50))), y=df.tail(50)['current_a'], mode='lines', name='History', line=dict(color='#3b82f6', width=2)))
                fp3.add_trace(go.Scatter(x=fxc, y=fyc, mode='lines', name='Forecast', line=dict(color='#60a5fa', width=2, dash='dot')))
                fp3.add_hline(y=10.0, line_dash="dash", line_color="#333", annotation_text="Limit")
                fp3.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=20), paper_bgcolor='white', plot_bgcolor='rgba(0,0,0,0)', showlegend=True, legend=dict(orientation="h", y=1.1))
                st.plotly_chart(fp3, use_container_width=True, key=f"p3_{u_key}")
                st.markdown(f"""<div class="pred-box" style="border-left-color: {tcc}"><h4 style="margin:0; color:{tcc}">{T['status']}: {tmc}</h4></div>""", unsafe_allow_html=True)

        # 2. توقعات الفولتية
        with pc4:
            st.markdown(f"#### {T['volt']}")
            
            fxv_v, fyv_v, tmv_v, tcv_v = calculate_trend_and_prediction(df, 'voltage_v', 250.0)
            if fxv_v is not None:
                fp4 = go.Figure()
                fp4.add_trace(go.Scatter(x=np.arange(len(df.tail(50))), y=df.tail(50)['voltage_v'], mode='lines', name='History', line=dict(color='#10b981', width=2)))
                fp4.add_trace(go.Scatter(x=fxv_v, y=fyv_v, mode='lines', name='Forecast', line=dict(color='#34d399', width=2, dash='dot')))
                fp4.add_hline(y=250.0, line_dash="dash", line_color="#333", annotation_text="Limit")
                fp4.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=20), paper_bgcolor='white', plot_bgcolor='rgba(0,0,0,0)', showlegend=True, legend=dict(orientation="h", y=1.1))
                st.plotly_chart(fp4, use_container_width=True, key=f"p4_{u_key}")
                st.markdown(f"""<div class="pred-box" style="border-left-color: {tcv_v}"><h4 style="margin:0; color:{tcv_v}">{T['status']}: {tmv_v}</h4></div>""", unsafe_allow_html=True)
                
        # متوسط آخر 20 قراءة لدرجة الخطر 
        smooth_score = df['anomaly_score'].rolling(window=20, min_periods=1).mean().iloc[-1]
        
        
        rul = max(0, 100 - (smooth_score * 100))
        
       
        st.progress(rul/100, text=f"{T['rul']}: {rul:.1f}%")

    time.sleep(ref_rate)
