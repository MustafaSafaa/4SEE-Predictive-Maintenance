@echo off
cd /d "%~dp0"

echo ======================================================
echo      Starting Industrial Control System (IoT) ...
echo ======================================================

:: 1. تشغيل السيرفر 
start "WiFi Data Server" cmd /k "python wifi_server.py"

:: انتظر 3 ثواني
timeout /t 3 >nul

:: 2. تشغيل الداشبورد 
start "Control Dashboard" cmd /k "python -m streamlit run dashboard6.py"

echo.
echo System is running!
echo If windows close immediately, ensure Python is installed and added to PATH.
echo.
pause