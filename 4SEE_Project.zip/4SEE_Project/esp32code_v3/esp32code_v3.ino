#include <WiFi.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>

// ==========================================
//  إعدادات الشبكة
// ==========================================
const char* ssid     = "1st floor_IOT";
const char* password = "22085351";
const char* host     = "192.168.0.222"; 
const int port       = 8080;

// ==========================================

const int tempPin    = 4;   // حرارة
const int currentPin = 35;  // تيار
const int acVoltPin  = 33;  // جهد المنزل
// ADXL345: SDA=21, SCL=22

// ==========================================
//  إعدادات المعايرة الدقيقة
// ==========================================

// 1. معايرة التيار (ACS712 - 5A)
// الحساسية القياسية عند تغذية 5 فولت
const float currentSensitivity = 0.185; 

//  نقطة الصفر الخاصة بك (التي قسناها للتو)
float currentZeroPoint = 2.35; 

// 2. معايرة جهد المنزل
double acVoltCalibration = 550.0; 

// ==========================================
//  الكائنات
// ==========================================
OneWire oneWire(tempPin);
DallasTemperature sensors(&oneWire);
Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(12345);

void setup() {
  Serial.begin(115200);
  sensors.begin();
  
  // تشغيل ADXL345
  if(!accel.begin()) {
    Serial.println("❌ ADXL345 not detected!");
  } else {
    accel.setRange(ADXL345_RANGE_16_G);
    Serial.println("✅ ADXL345 Connected");
  }

  pinMode(currentPin, INPUT);
  pinMode(acVoltPin, INPUT);

  // الواي فاي
  Serial.print("Connecting to WiFi");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500); Serial.print(".");
  }
  Serial.println("\n✅ WiFi Connected!");
}

// ---------------------------------------------------------
//  دالة قراءة التيار (AC Current)
// ---------------------------------------------------------
float readACCurrent() {
  float sum = 0; int counter = 0; long startTime = millis();
  
  while (millis() - startTime < 200) {
    int raw = analogRead(currentPin);
    
    // 1. تحويل القراءة الرقمية لفولتية (ESP يقرأ 0-3.3 فولت)
    float v_inst = (raw / 4095.0) * 3.3;
    
    // 2. طرح نقطة الصفر  (2.35)
    float voltage = v_inst - currentZeroPoint;
    
    sum += voltage * voltage;
    counter++;
    delayMicroseconds(50);
  }
  
  float v_rms = sqrt(sum / counter);
  float current = v_rms / currentSensitivity;

  // تصفير أي تشويش أقل من 0.1 أمبير
  if(current < 0.1) current = 0;
  
  return current;
}

// ---------------------------------------------------------
//  دالة قراءة الجهد 
// ---------------------------------------------------------
float readACVoltage() {
  float sum = 0; int counter = 0; long startTime = millis();
  while (millis() - startTime < 200) {
    int raw = analogRead(acVoltPin);
    float v = ((raw / 4095.0) * 3.3) - 1.65;
    sum += v * v;
    counter++; delayMicroseconds(50);
  }
  float val = sqrt(sum / counter) * acVoltCalibration;
  return (val < 10) ? 0 : val;
}

void loop() {
  // 1. حرارة
  sensors.requestTemperatures(); 
  float temp = sensors.getTempCByIndex(0);

  // 2. اهتزاز (قيمة Z المباشرة لتناسب سيرفرك القديم)
  sensors_event_t event; 
  accel.getEvent(&event);
  float vib = fabs(event.acceleration.z); 

  // 3. تيار
  float amps = readACCurrent();

  // 4. جهد منزل
  float acVolt = readACVoltage();

  // طباعة
  Serial.printf("Temp: %.1f, Vib: %.2f, Amps: %.2f, Volt: %.0f\n", temp, vib, amps, acVolt);

  // إرسال
  WiFiClient client;
  if (client.connect(host, port)) {
    String data = String(temp) + "," + String(vib) + "," + String(amps) + "," + String(acVolt);
    client.print(data);
    Serial.println("Sent: " + data);
    client.stop();
  } else {
    Serial.println("❌ Connection Failed");
  }

  delay(1000);
}