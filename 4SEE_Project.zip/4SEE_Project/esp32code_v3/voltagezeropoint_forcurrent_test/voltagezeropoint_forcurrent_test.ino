#include <Arduino.h>

const int currentPin = 35; 

void setup() {
  Serial.begin(115200);
  pinMode(currentPin, INPUT);
}

void loop() {
  long sum = 0;
  // نأخذ متوسط 1000 قراءة للدقة التامة
  for(int i=0; i<1000; i++){
    sum += analogRead(currentPin);
    delayMicroseconds(10);
  }
  float avgRaw = sum / 1000.0;
  
  // تحويل القراءة الرقمية إلى فولتية
  float voltage = (avgRaw / 4095.0) * 3.3;

  Serial.println("-------------------------");
  Serial.print("Raw Value: "); Serial.print(avgRaw);
  Serial.print("  |  REAL VOLTAGE: "); Serial.println(voltage, 4); // دقة 4 أرقام
  Serial.println("-------------------------");

  delay(500);
}